package main

import (
	"context"
	"fmt"
	"log"

	"github.com/lh123aa/cortex/internal/embedding"
	"github.com/lh123aa/cortex/internal/index"
	"github.com/lh123aa/cortex/internal/models"
	"github.com/lh123aa/cortex/internal/rag"
	"github.com/lh123aa/cortex/internal/search"
	"github.com/lh123aa/cortex/internal/storage"
	"github.com/spf13/cobra"
	"github.com/lh123aa/cortex/internal/api"
	"go.uber.org/zap"
	"os"
)

var (
	defaultDbPath     = "cortex.db"
)

func getEnvOrDefault(key, fallback string) string {
	if val := os.Getenv(key); val != "" {
		return val
	}
	return fallback
}

func main() {
	var rootCmd = &cobra.Command{
		Use:   "cortex",
		Short: "Cortex is an Agent Knowledge Base",
	}

	rootCmd.AddCommand(indexCmd())
	rootCmd.AddCommand(watchCmd())
	rootCmd.AddCommand(searchCmd())
	rootCmd.AddCommand(contextCmd())
	rootCmd.AddCommand(serveCmd())
	rootCmd.AddCommand(backupCmd())

	if err := rootCmd.Execute(); err != nil {
		log.Fatalf("cortex run error: %v", err)
	}
}

func backupCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "backup",
		Short: "Backup the SQLite storage safely",
		Run: func(cmd *cobra.Command, args []string) {
			dbPath := getEnvOrDefault("CORTEX_DB_PATH", defaultDbPath)
			bm := storage.NewBackupManager(dbPath)
			log.Printf("Starting hot backup of %s...", dbPath)
			
			dest, err := bm.CreateBackup()
			if err != nil {
				log.Fatalf("Backup failed: %v", err)
			}
			log.Printf("Backup successfully created at: %s", dest)
		},
	}
}

func getInstances() (storage.Storage, embedding.EmbeddingProvider) {
	dbPath := getEnvOrDefault("CORTEX_DB_PATH", defaultDbPath)
	
	st, err := storage.NewSQLiteStorage(dbPath)
	if err != nil {
		log.Fatalf("DB Init failed: %v\n", err)
	}
	
	ollamaURL := getEnvOrDefault("OLLAMA_HOST", "http://localhost:11434")
	ollamaModel := getEnvOrDefault("OLLAMA_MODEL", "nomic-embed-text")
	
	emb := embedding.NewOllamaEmbedding(ollamaURL, ollamaModel, 768)
	return st, emb
}

func indexCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "index [path]",
		Short: "Index a directory",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			st, emb := getInstances()
			defer st.Close()

			idx := index.NewIndexer(st, emb)
			log.Printf("Start indexing folder: %s\n", args[0])
			res, err := idx.IndexDirectory(args[0])
			if err != nil {
				log.Fatalf("Index failed: %v", err)
			}
			log.Printf("Successfully indexed! Processed: %d, Failed: %d\n", res.Indexed, res.Failed)
		},
	}
}

func watchCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "watch [path]",
		Short: "Auto-index daemon that watches a directory for changes",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			st, emb := getInstances()
			defer st.Close()

			idx := index.NewIndexer(st, emb)
			log.Printf("Initializing Cortex Watcher Daemon...")
			
			if err := idx.StartWatcher(args[0]); err != nil {
				log.Fatalf("Watcher terminated with error: %v", err)
			}
		},
	}
}

func searchCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "search [query]",
		Short: "Hybrid search the knowledge base",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			st, emb := getInstances()
			defer st.Close()

			engine := search.NewHybridSearchEngine(st, emb)
			opts := models.SearchOptions{TopK: 5, Mode: "hybrid"}

			log.Printf("Searching for: '%s'\n", args[0])
			results, err := engine.Search(context.Background(), args[0], opts)
			if err != nil {
				log.Fatalf("Search failed: %v", err)
			}

			fmt.Println("--- Search Results ---")
			for _, r := range results {
				fmt.Printf("[Rank %d / Score %.2f] %s: %s\n", r.Rank, r.Score, r.Chunk.DocumentID, r.Chunk.ContentRaw[:min(len(r.Chunk.ContentRaw), 100)]+"...")
			}
		},
	}
}

func contextCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "context [query]",
		Short: "Get RAG assembled Context",
		Args:  cobra.ExactArgs(1),
		Run: func(cmd *cobra.Command, args []string) {
			st, emb := getInstances()
			defer st.Close()

			engine := search.NewHybridSearchEngine(st, emb)
			builder := rag.NewRAGBuilder(engine)
			opts := models.SearchOptions{TopK: 50, Mode: "hybrid"}

			rc, err := builder.BuildContext(context.Background(), args[0], 1000, opts)
			if err != nil {
				log.Fatalf("Build context failed: %v", err)
			}

			fmt.Println("--- Generated Context ---")
			fmt.Printf("Token Used: %d / %d\n", rc.TokenCount, rc.TokenBudget)
			fmt.Println(rc.Context)
		},
	}
}

func serveCmd() *cobra.Command {
	return &cobra.Command{
		Use:   "mcp",
		Short: "Start the Cortex MCP server over stdio",
		Run: func(cmd *cobra.Command, args []string) {
			st, emb := getInstances()
			defer st.Close()

			engine := search.NewHybridSearchEngine(st, emb)
			
			// Setup Zap Logger (for MCP, we MUST output to stderr since stdout is for JsonRPC payload)
			cfg := zap.NewProductionConfig()
			cfg.OutputPaths = []string{"stderr"}
			logger, _ := cfg.Build()
			defer logger.Sync()

			logger.Info("Starting Cortex MCP Server over Stdio")

			// Initialize and run MCP server
			mcpServer := api.NewMCPServer(engine, st, logger)
			if err := mcpServer.Run(); err != nil {
				logger.Fatal("Failed to run MCP Server", zap.Error(err))
			}
		},
	}
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}
